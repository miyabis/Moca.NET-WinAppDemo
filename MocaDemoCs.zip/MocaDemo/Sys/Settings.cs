﻿
namespace MocaDemo.Sys
{
	public class Settings
	{
		public const string ConnectionStrings = "MocaDemo.Properties.Settings.Db";
	}
}
